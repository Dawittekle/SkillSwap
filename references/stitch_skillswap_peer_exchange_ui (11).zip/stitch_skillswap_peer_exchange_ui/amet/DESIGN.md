---
name: Amet
colors:
  surface: '#f7f9ff'
  surface-dim: '#d1dbe8'
  surface-bright: '#f7f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#edf4ff'
  surface-container: '#e4effd'
  surface-container-high: '#dfe9f7'
  surface-container-highest: '#d9e3f1'
  on-surface: '#121d26'
  on-surface-variant: '#3e4947'
  inverse-surface: '#27313c'
  inverse-on-surface: '#e8f2ff'
  outline: '#6e7977'
  outline-variant: '#bdc9c6'
  surface-tint: '#006a63'
  primary: '#005c55'
  on-primary: '#ffffff'
  primary-container: '#0f766e'
  on-primary-container: '#a3faef'
  inverse-primary: '#80d5cb'
  secondary: '#7d5800'
  on-secondary: '#ffffff'
  secondary-container: '#fdbf47'
  on-secondary-container: '#704e00'
  tertiary: '#0c5b56'
  on-tertiary: '#ffffff'
  tertiary-container: '#2f746f'
  on-tertiary-container: '#b3f7f0'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#9cf2e8'
  primary-fixed-dim: '#80d5cb'
  on-primary-fixed: '#00201d'
  on-primary-fixed-variant: '#00504a'
  secondary-fixed: '#ffdea9'
  secondary-fixed-dim: '#fabc45'
  on-secondary-fixed: '#271900'
  on-secondary-fixed-variant: '#5f4100'
  tertiary-fixed: '#abefe8'
  tertiary-fixed-dim: '#8fd3cc'
  on-tertiary-fixed: '#00201e'
  on-tertiary-fixed-variant: '#00504b'
  background: '#f7f9ff'
  on-background: '#121d26'
  surface-variant: '#d9e3f1'
typography:
  display:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 16px
  lg: 24px
  xl: 40px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 64px
  max-width: 1280px
---

## Brand & Style

The design system is crafted for a community-driven exchange of knowledge, specifically tailored for the Ethiopian student demographic. The brand personality is **scholarly yet accessible**, balancing traditional warmth with modern technical precision. It avoids literal cultural clichés in favor of a sophisticated "Modern Ethiopian" aesthetic that feels globally competitive while remaining locally resonant.

The design style is **Corporate / Modern** with a high-end editorial influence. It prioritizes clarity through generous whitespace, structured layouts, and a refined color palette that evokes growth (Teal) and enlightenment (Gold). The emotional response should be one of reliability, optimism, and academic focus.

## Colors

The palette is anchored by a deep Teal primary, symbolizing growth and stability, paired with a warm Gold accent that represents value and wisdom. 

- **Primary & Dark Teal:** Used for brand identifiers, primary actions, and navigational anchors.
- **Accent & Soft Gold:** Reserved for high-priority calls to action, achievement badges, and subtle highlights. The soft gold serves as an excellent low-contrast background for informational banners.
- **Warm Neutrals:** The page background uses a soft off-white to reduce eye strain during long study sessions, while pure white is reserved for interactive cards to create a clear "layering" effect.
- **Functional Colors:** Standardized semantic colors for system feedback, ensuring accessibility and quick recognition of status changes.

## Typography

The design system utilizes **Plus Jakarta Sans** exclusively to maintain a cohesive, modern, and friendly voice. The typeface’s open counters and geometric structure ensure high legibility on both mobile screens and desktop monitors.

- **Headlines:** Use tighter letter-spacing and heavier weights to create a strong visual hierarchy.
- **Body Text:** Set with generous line-heights to facilitate comfortable reading of educational content and skill descriptions.
- **Labels:** Used for metadata, chips, and small captions; these utilize a medium weight to maintain presence even at small sizes.

## Layout & Spacing

This design system employs a **12-column fluid grid** for desktop and a **4-column fluid grid** for mobile devices. The rhythm is based on an 8px square grid to ensure consistent alignment.

- **Desktop:** 12 columns with 24px gutters. The layout is centered with a max-width of 1280px to prevent excessive line lengths on wide monitors.
- **Mobile:** 4 columns with 16px margins.
- **Reflow Rules:** Elements should stack vertically on mobile. Cards and interactive modules should span the full width of the mobile grid minus the side margins.
- **Spacing Philosophy:** Use "generous breathing room." Avoid crowding text; use `xl` (40px) spacing between major sections to emphasize clarity and focus.

## Elevation & Depth

Visual hierarchy is established through **Tonal Layers** and **Ambient Shadows**. This approach creates a sense of "physical" paper-like layers, appropriate for an educational context.

- **Base Layer:** The `Background Warm` (#FAF7F0) acts as the canvas.
- **Surface Layer:** White cards and containers sit atop the base. They use a very subtle, extra-diffused shadow (`blur: 12px, y: 4px, color: rgba(31, 41, 51, 0.05)`) to appear slightly lifted.
- **Interactive Layer:** Elements like primary buttons or active states use the `Accent Gold` to pop forward. 
- **Outlines:** Low-contrast borders (#E5E7EB) are used to define boundaries on white surfaces where shadows would be too heavy.

## Shapes

The design system uses a **Rounded** shape language to appear welcoming and contemporary. 

- **Small Components:** Checkboxes and small tags use `0.25rem` (Soft) to maintain precision.
- **Standard Components:** Buttons, input fields, and standard cards use `0.5rem` (Rounded).
- **Large Components:** Hero sections and prominent promotional cards use `1rem` (Rounded-lg).
- **Pill Shapes:** Search bars and "category" chips should use a fully rounded (pill) style to distinguish them as easily tappable/filterable elements.

## Components

### Buttons
- **Primary:** Filled `Accent Gold` with `Text Dark` labels. This provides maximum contrast and draws immediate attention.
- **Secondary:** Outlined `Primary Green` with a 1.5px border.
- **Ghost:** No background, `Primary Green` text, used for less frequent actions.

### Input Fields
- White background with `Border` (#E5E7EB). On focus, the border transitions to `Primary Green` with a subtle 2px outer glow in the same color (20% opacity).

### Cards
- Always white background. Use `rounded-lg` (1rem). Padding should be at least `lg` (24px) to maintain the "generous spacing" brand pillar.

### Chips & Badges
- **Skill Chips:** `Soft Gold` background with `Primary Dark` text. 
- **Status Badges:** Use semantic colors with a 10% opacity background and 100% opacity text of the same hue.

### Lists
- Use horizontal dividers (#E5E7EB) with `lg` (24px) vertical padding between items. Every list item should have a clear leading icon or avatar for quick scanning.

### Specialized Components
- **Progress Tracker:** A vertical timeline using `Primary Green` for completed steps and `Border` for upcoming ones, designed for tracking skill-acquisition milestones.