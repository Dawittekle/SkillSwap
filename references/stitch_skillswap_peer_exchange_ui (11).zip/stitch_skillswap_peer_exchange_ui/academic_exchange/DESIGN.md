---
name: Academic Exchange
colors:
  surface: '#fcf8fb'
  surface-dim: '#dcd9dc'
  surface-bright: '#fcf8fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f5'
  surface-container: '#f0edef'
  surface-container-high: '#eae7ea'
  surface-container-highest: '#e4e2e4'
  on-surface: '#1b1b1d'
  on-surface-variant: '#464554'
  inverse-surface: '#303032'
  inverse-on-surface: '#f3f0f2'
  outline: '#777586'
  outline-variant: '#c7c4d7'
  surface-tint: '#4d4ad5'
  primary: '#4441cc'
  on-primary: '#ffffff'
  primary-container: '#5e5ce6'
  on-primary-container: '#f4f1ff'
  inverse-primary: '#c2c1ff'
  secondary: '#006e28'
  on-secondary: '#ffffff'
  secondary-container: '#6ffb85'
  on-secondary-container: '#00732a'
  tertiary: '#7c4b00'
  on-tertiary: '#ffffff'
  tertiary-container: '#9e6000'
  on-tertiary-container: '#ffefe3'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c2c1ff'
  on-primary-fixed: '#0c006b'
  on-primary-fixed-variant: '#332dbc'
  secondary-fixed: '#72fe88'
  secondary-fixed-dim: '#53e16f'
  on-secondary-fixed: '#002107'
  on-secondary-fixed-variant: '#00531c'
  tertiary-fixed: '#ffddbb'
  tertiary-fixed-dim: '#ffb868'
  on-tertiary-fixed: '#2b1700'
  on-tertiary-fixed-variant: '#673d00'
  background: '#fcf8fb'
  on-background: '#1b1b1d'
  surface-variant: '#e4e2e4'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 40px
  xl: 64px
  gutter: 20px
  margin-mobile: 16px
  margin-desktop: 48px
---

## Brand & Style
The design system is centered on a **Modern / Corporate** aesthetic refined for a student demographic. It prioritizes clarity, warmth, and peer-to-peer trust. The goal is to evoke a sense of collaborative optimism, moving away from sterile institutional software toward a vibrant, community-focused ecosystem. 

The visual language balances the precision of a productivity tool with the approachability of a social network. High-quality whitespace and a limited color palette ensure the platform feels spacious and organized, reducing cognitive load for students managing complex schedules.

## Colors
The palette uses a sophisticated **Deep Indigo** as the primary driver for brand identity and actions. This color conveys intelligence and stability. **Fresh Mint** is reserved for positive reinforcement, such as successful skill matches, completed sessions, and growth indicators.

- **Primary (#5E5CE6):** Main buttons, active navigation states, and brand-critical icons.
- **Secondary (#34C759):** "Teaches" indicators, success messages, and availability badges.
- **Surface (#FFFFFF):** Used for all interactive cards and modals to create "lift" from the off-white background.
- **Text:** Primary copy uses a high-contrast dark gray (#1C1C1E) for maximum legibility, while secondary labels use a medium slate (#636366).

## Typography
This design system employs a dual-font strategy. **Plus Jakarta Sans** is used for headings to provide a friendly, open, and slightly rounded modern feel that differentiates the platform from standard SaaS tools. 

**Inter** is utilized for all body copy and UI labels due to its exceptional readability and systematic nature. Use `headline-xl` sparingly for landing hero sections, and `headline-md` for standard card titles. Letter spacing is tightened on large headlines to maintain visual density.

## Layout & Spacing
The layout follows a **Fluid Grid** model with an 8px base unit. 

- **Desktop:** 12-column grid with 20px gutters. Maximum content width is 1280px.
- **Tablet:** 8-column grid with 16px gutters.
- **Mobile:** 4-column grid with 12px gutters and 16px side margins.

Horizontal spacing between related elements (like a label and an input) should use `sm` (12px), while vertical spacing between distinct sections should use `lg` (40px).

## Elevation & Depth
Depth is expressed through **Ambient Shadows** and **Tonal Layers**. 

Interactive elements like cards and buttons should use a soft, multi-layered shadow with a subtle blue tint (#5E5CE6 at 4% opacity) to prevent them from feeling "muddy." A 1px border (#E5E7EB) is applied to all surface containers to maintain definition even when shadows are subtle.

- **Level 0 (Background):** #F8F9FA.
- **Level 1 (Cards):** #FFFFFF with 1px border and low-offset shadow (4px blur).
- **Level 2 (Modals/Hover):** #FFFFFF with high-offset shadow (12px blur) to indicate immediate priority.

## Shapes
The shape language is consistently **Rounded**. 

Large containers (User Profiles, Skill Cards) use a 16px radius (`rounded-lg`). Standard UI components like buttons and input fields use an 8px radius. Small utility elements like category chips and badges use a 24px "Pill" radius to distinguish them from interactive action buttons.

## Components
### Buttons
- **Primary:** Solid #5E5CE6 with white text. 8px radius. Height: 48px for main actions.
- **Secondary:** 1px #5E5CE6 border with #5E5CE6 text. No fill. 8px radius.
- **Ghost:** No border or fill. Used for "Cancel" or less frequent navigation items.

### Skill Cards
Cards must utilize the "Match Language":
- **Header:** User avatar and name.
- **Body:** Use a 2-column split or vertical stack. Label "Teaches" with a Fresh Mint icon/pill and "Wants" with a Primary Indigo icon/pill.
- **Footer:** Simple 1px top divider with a "Connect" primary button.

### Inputs
Text fields should have a 1px #E5E7EB border, 8px radius, and a 16px internal padding. On focus, the border transitions to Primary Indigo with a 2px outer glow.

### Chips & Badges
- **Skill Chips:** Light gray background (#F1F3F5) with dark gray text. Use a 24px pill shape. 
- **Status Badges:** Use a light version of the semantic color (e.g., 10% opacity Mint for "Available") with the full-strength color for the text.